# Project health (OSS)

This document tracks core community and maintenance documents for Eigen OS.

## Community files status

| File | Status | Notes |
|---|---|---|
| `README.md` | ✅ Present | Project overview and entry points. |
| `LICENSE` | ✅ Present | Apache-2.0 license. |
| `CONTRIBUTING.md` | ✅ Present | Contribution workflow, RFC process, and test commands. |
| `CODE_OF_CONDUCT.md` | ✅ Present | Community behavior expectations. |
| `SECURITY.md` | ✅ Present | Private vulnerability reporting process. |
| `CHANGELOG.md` | ✅ Present | Keep a Changelog + SemVer policy. |
| `GOVERNANCE.md` | ✅ Present | Governance model and maintainer expectations. |
| `SECURITY_HALL_OF_FAME.md` | ✅ Present | Security contributor recognition. |

## Documentation hygiene checks

- MVP-2 RFC/ADR package is documented in `docs/rfcs-pointer.md`, `rfcs/0013`-`0015`, and `docs/adr/0003`-`0005`.
- Phase-5 RFC/ADR closure package is documented in `docs/rfcs-pointer.md`, `rfcs/0026`-`0028`, and `docs/adr/0014`-`0016`.
- Phase-8B RFC/ADR closure package is documented in `docs/rfcs-pointer.md`, `rfcs/0038`-`0040`, `docs/adr/0024`-`0026`, and `docs/development/phase-8b/`.
- Roadmap no longer contains placeholder content.
- Project health status is tracked in this file instead of open checklist placeholders.

## Maintenance cadence

- Re-check this document at each milestone/release (including post-MVP phases).
- Update status when adding/removing top-level governance or policy docs.
