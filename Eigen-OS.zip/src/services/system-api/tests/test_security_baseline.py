from __future__ import annotations

import socket
import time
import urllib.request
import base64
import hashlib
import hmac
import json

import grpc
import pytest
from google.rpc import error_details_pb2
from grpc_status import rpc_status

from system_api.grpc_server import serve
from system_api.observability import start_metrics_server
from system_api.proto_gen import ensure_generated

ensure_generated()

from eigen.api.v1 import device_service_pb2 as dev_pb  # noqa: E402
from eigen.api.v1 import device_service_pb2_grpc as dev_pb_grpc  # noqa: E402
from eigen.api.v1 import job_service_pb2 as job_pb  # noqa: E402
from eigen.api.v1 import job_service_pb2_grpc as job_pb_grpc  # noqa: E402
from eigen.api.v1 import types_pb2 as types_pb  # noqa: E402


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


def _extract_bad_request(err: grpc.RpcError) -> error_details_pb2.BadRequest:
    st = rpc_status.from_call(err)
    assert st is not None
    bad = error_details_pb2.BadRequest()
    assert len(st.details) >= 1
    assert any(detail.Unpack(bad) for detail in st.details)
    return bad


def _extract_error_info(err: grpc.RpcError) -> error_details_pb2.ErrorInfo:
    st = rpc_status.from_call(err)
    assert st is not None
    info = error_details_pb2.ErrorInfo()
    assert len(st.details) >= 1
    assert st.details[0].Unpack(info)
    return info


def _jwt(secret: str, claims: dict[str, object]) -> str:
    def b64(data: bytes) -> str:
        return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")
    header = {"alg": "HS256", "typ": "JWT"}
    header_b64 = b64(json.dumps(header, separators=(",", ":"), sort_keys=True).encode("utf-8"))
    payload_b64 = b64(json.dumps(claims, separators=(",", ":"), sort_keys=True).encode("utf-8"))
    signing_input = f"{header_b64}.{payload_b64}".encode("ascii")
    sig = hmac.new(secret.encode("utf-8"), signing_input, hashlib.sha256).digest()
    return f"{header_b64}.{payload_b64}.{b64(sig)}"


def test_auth_static_token_mode_requires_authorization(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("SYSTEM_API_AUTH_MODE", "static_token")
    monkeypatch.setenv("SYSTEM_API_AUTH_TOKEN", "test-token")
    monkeypatch.setenv("SYSTEM_API_AUTH_SUBJECT", "test-user")
    monkeypatch.setenv("SYSTEM_API_AUTH_TENANT", "test-tenant")

    addr = f"127.0.0.1:{_free_port()}"
    server = serve(bind=addr)
    time.sleep(0.05)

    try:
        channel = grpc.insecure_channel(addr)
        stub = dev_pb_grpc.DeviceServiceStub(channel)

        with pytest.raises(grpc.RpcError) as exc:
            stub.ListDevices(dev_pb.ListDevicesRequest())
        assert exc.value.code() == grpc.StatusCode.UNAUTHENTICATED

        with pytest.raises(grpc.RpcError) as exc_perm:
            stub.ListDevices(
                dev_pb.ListDevicesRequest(),
                metadata=(("authorization", "Bearer test-token"),),
            )
        assert exc_perm.value.code() == grpc.StatusCode.PERMISSION_DENIED

        ok = stub.ListDevices(
            dev_pb.ListDevicesRequest(),
            metadata=(
                ("authorization", "Bearer test-token"),
                ("x-eigen-permissions", "devices:list"),
            ),
        )
        assert len(ok.devices) == 1
    finally:
        server.stop(grace=None)


def test_submit_job_enforces_source_and_yaml_size_limits(
    grpc_addr: str,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("SYSTEM_API_MAX_PROGRAM_SOURCE_BYTES", "8")
    monkeypatch.setenv("SYSTEM_API_MAX_JOBSPEC_YAML_BYTES", "10")

    channel = grpc.insecure_channel(grpc_addr)
    stub = job_pb_grpc.JobServiceStub(channel)

    with pytest.raises(grpc.RpcError) as exc:
        stub.SubmitJob(
            job_pb.SubmitJobRequest(
                name="size-check",
                target="sim:local",
                eigen_lang=types_pb.EigenLangSource(
                    source=b"def main():\n    return 1",
                    entrypoint="main",
                ),
                metadata={"jobspec_yaml": "a: 1\nb: 2\nc: 3"},
            )
        )

    assert exc.value.code() == grpc.StatusCode.RESOURCE_EXHAUSTED
    bad = _extract_bad_request(exc.value)
    fields = {v.field for v in bad.field_violations}
    assert "eigen_lang.source" in fields
    assert "metadata[jobspec_yaml]" in fields


def test_authz_readonly_cannot_submit_but_can_list_devices(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("SYSTEM_API_AUTH_MODE", "static_token")
    monkeypatch.setenv("SYSTEM_API_AUTH_TOKEN", "readonly-token")
    monkeypatch.setenv("SYSTEM_API_AUTH_ROLES", "readonly")
    monkeypatch.setenv("SYSTEM_API_AUTH_SUBJECT", "readonly-user")
    monkeypatch.setenv("SYSTEM_API_AUTH_TENANT", "readonly-tenant")

    addr = f"127.0.0.1:{_free_port()}"
    server = serve(bind=addr)
    time.sleep(0.05)

    try:
        channel = grpc.insecure_channel(addr)
        job_stub = job_pb_grpc.JobServiceStub(channel)
        dev_stub = dev_pb_grpc.DeviceServiceStub(channel)
        md = (("authorization", "Bearer readonly-token"),)

        ok = dev_stub.ListDevices(dev_pb.ListDevicesRequest(), metadata=md)
        assert len(ok.devices) == 1

        with pytest.raises(grpc.RpcError) as exc:
            job_stub.SubmitJob(
                job_pb.SubmitJobRequest(
                    name="denied-submit",
                    target="sim:local",
                    eigen_lang=types_pb.EigenLangSource(source=b"def main():\n    return 0", entrypoint="main"),
                ),
                metadata=md,
            )
        assert exc.value.code() == grpc.StatusCode.PERMISSION_DENIED
    finally:
        server.stop(grace=None)


def test_expired_jwt_token_is_rejected(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("SYSTEM_API_AUTH_MODE", "jwt_oauth2")
    monkeypatch.setenv("SYSTEM_API_AUTH_JWT_SECRET", "jwt-secret")
    monkeypatch.setenv("SYSTEM_API_AUTH_ISSUER", "eigen-auth")
    monkeypatch.setenv("SYSTEM_API_AUTH_AUDIENCE", "eigen-api")
    monkeypatch.setenv("SYSTEM_API_AUTH_SUBJECT", "jwt-user")
    monkeypatch.setenv("SYSTEM_API_AUTH_TENANT", "jwt-tenant")

    addr = f"127.0.0.1:{_free_port()}"
    server = serve(bind=addr)
    time.sleep(0.05)
    try:
        channel = grpc.insecure_channel(addr)
        stub = dev_pb_grpc.DeviceServiceStub(channel)
        token = _jwt("jwt-secret", {"iss": "eigen-auth", "aud": "eigen-api", "exp": 1, "sub": "jwt-user"})
        with pytest.raises(grpc.RpcError) as exc:
            stub.ListDevices(dev_pb.ListDevicesRequest(), metadata=(("authorization", f"Bearer {token}"),))
        assert exc.value.code() == grpc.StatusCode.UNAUTHENTICATED
    finally:
        server.stop(grace=None)


def test_policy_backend_outage_fails_closed(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("SYSTEM_API_AUTH_MODE", "static_token")
    monkeypatch.setenv("SYSTEM_API_AUTH_TOKEN", "outage-token")
    monkeypatch.setenv("SYSTEM_API_AUTH_SUBJECT", "outage-user")
    monkeypatch.setenv("SYSTEM_API_AUTH_TENANT", "outage-tenant")
    monkeypatch.setenv("SYSTEM_API_POLICY_SNAPSHOT_PATH", str(tmp_path / "missing.json"))

    addr = f"127.0.0.1:{_free_port()}"
    server = serve(bind=addr)
    time.sleep(0.05)
    try:
        channel = grpc.insecure_channel(addr)
        stub = dev_pb_grpc.DeviceServiceStub(channel)
        with pytest.raises(grpc.RpcError) as exc:
            stub.ListDevices(dev_pb.ListDevicesRequest(), metadata=(("authorization", "Bearer outage-token"),))
        assert exc.value.code() == grpc.StatusCode.PERMISSION_DENIED
        info = _extract_error_info(exc.value)
        assert info.metadata["policy"] == "POLICY_BACKEND_UNAVAILABLE"
    finally:
        server.stop(grace=None)


def test_security_audit_sink_persists_and_sanitizes(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    audit_path = tmp_path / "audit.jsonl"
    monkeypatch.setenv("SYSTEM_API_AUDIT_SINK_PATH", str(audit_path))
    monkeypatch.setenv("SYSTEM_API_AUTH_MODE", "static_token")
    monkeypatch.setenv("SYSTEM_API_AUTH_TOKEN", "audit-token")
    monkeypatch.setenv("SYSTEM_API_AUTH_SUBJECT", "audit-user")
    monkeypatch.setenv("SYSTEM_API_AUTH_TENANT", "audit-tenant")
    monkeypatch.setenv("SYSTEM_API_AUTH_ROLES", "readonly")

    addr = f"127.0.0.1:{_free_port()}"
    server = serve(bind=addr)
    time.sleep(0.05)
    try:
        channel = grpc.insecure_channel(addr)
        job_stub = job_pb_grpc.JobServiceStub(channel)
        md = (("authorization", "Bearer audit-token"),)
        with pytest.raises(grpc.RpcError):
            job_stub.CancelJob(job_pb.CancelJobRequest(job_id="job_123"), metadata=md)
        assert audit_path.exists()
        body = audit_path.read_text(encoding="utf-8").strip().splitlines()
        assert body
        audit = json.loads(body[-1])
        assert audit["decision"] == "deny"
        assert audit["subject"] == "audit-user"
        assert audit["trace_id"] == "" or "trace_id" in audit
        assert "Bearer audit-token" not in audit_path.read_text(encoding="utf-8")
    finally:
        server.stop(grace=None)


def test_metrics_include_authz_denied_counter(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("SYSTEM_API_AUTH_MODE", "static_token")
    monkeypatch.setenv("SYSTEM_API_AUTH_TOKEN", "readonly-metrics")
    monkeypatch.setenv("SYSTEM_API_AUTH_ROLES", "readonly")
    metrics_port = _free_port()
    monkeypatch.setenv("SYSTEM_API_METRICS_PORT", str(metrics_port))

    addr = f"127.0.0.1:{_free_port()}"
    metrics_server = start_metrics_server(metrics_port)
    server = serve(bind=addr)
    time.sleep(0.05)

    try:
        channel = grpc.insecure_channel(addr)
        job_stub = job_pb_grpc.JobServiceStub(channel)
        md = (("authorization", "Bearer readonly-metrics"),)
        with pytest.raises(grpc.RpcError):
            job_stub.CancelJob(job_pb.CancelJobRequest(job_id="job_123"), metadata=md)

        with urllib.request.urlopen(f"http://127.0.0.1:{metrics_port}/metrics", timeout=2.0) as resp:
            body = resp.read().decode("utf-8")
        assert "eigen_api_authz_denied_total" in body
    finally:
        server.stop(grace=None)
        metrics_server.shutdown()

def test_static_token_mode_fails_closed_on_missing_auth_context(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("SYSTEM_API_AUTH_MODE", "static_token")
    monkeypatch.setenv("SYSTEM_API_AUTH_TOKEN", "ctx-token")
    monkeypatch.setenv("SYSTEM_API_AUTH_ROLES", "admin")
    monkeypatch.setenv("SYSTEM_API_AUTH_SUBJECT", "")
    monkeypatch.setenv("SYSTEM_API_AUTH_TENANT", "")

    addr = f"127.0.0.1:{_free_port()}"
    server = serve(bind=addr)
    time.sleep(0.05)
    try:
        channel = grpc.insecure_channel(addr)
        stub = dev_pb_grpc.DeviceServiceStub(channel)
        with pytest.raises(grpc.RpcError) as exc:
            stub.ListDevices(
                dev_pb.ListDevicesRequest(),
                metadata=(("authorization", "Bearer ctx-token"),),
            )
        assert exc.value.code() == grpc.StatusCode.PERMISSION_DENIED
        info = _extract_error_info(exc.value)
        assert info.metadata["policy"] == "POLICY_DENY_MISSING_AUTH_CONTEXT"
    finally:
        server.stop(grace=None)


def test_cross_tenant_access_denied(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("SYSTEM_API_AUTH_MODE", "static_token")
    monkeypatch.setenv("SYSTEM_API_AUTH_TOKEN", "tenant-token")
    monkeypatch.setenv("SYSTEM_API_AUTH_ROLES", "user")
    monkeypatch.setenv("SYSTEM_API_AUTH_SUBJECT", "alice")
    monkeypatch.setenv("SYSTEM_API_AUTH_TENANT", "tenant-a")
    addr = f"127.0.0.1:{_free_port()}"
    server = serve(bind=addr)
    time.sleep(0.05)
    try:
        channel = grpc.insecure_channel(addr)
        job_stub = job_pb_grpc.JobServiceStub(channel)
        md = (("authorization", "Bearer tenant-token"),)
        submitted = job_stub.SubmitJob(
            job_pb.SubmitJobRequest(
                name="tenant-owned",
                target="sim:local",
                eigen_lang=types_pb.EigenLangSource(source=b"def main():\n    return 0", entrypoint="main"),
            ),
            metadata=md,
        )
        monkeypatch.setenv("SYSTEM_API_AUTH_TENANT", "tenant-b")
        with pytest.raises(grpc.RpcError) as exc:
            job_stub.GetJobStatus(job_pb.GetJobStatusRequest(job_id=submitted.job_id), metadata=md)
        assert exc.value.code() == grpc.StatusCode.PERMISSION_DENIED
        info = _extract_error_info(exc.value)
        assert info.metadata["policy"] == "POLICY_DENY_TENANT_MISMATCH"
    finally:
        server.stop(grace=None)
