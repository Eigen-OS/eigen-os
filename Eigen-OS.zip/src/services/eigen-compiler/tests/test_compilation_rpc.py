from __future__ import annotations

import grpc
import pytest
from google.rpc import error_details_pb2
from grpc_status import rpc_status

from eigen_compiler.proto_gen import ensure_generated

ensure_generated()

from eigen.internal.v1 import compilation_service_pb2 as comp_pb  # noqa: E402
from eigen.internal.v1 import compilation_service_pb2_grpc as comp_pb_grpc  # noqa: E402
from eigen.internal.v1 import types_pb2 as types_pb  # noqa: E402


def _enum_value(module, *names: str) -> int:
    for name in names:
        if hasattr(module, name):
            return int(getattr(module, name))
    raise AttributeError(f"None of enum names exist: {names}")


def _extract_bad_request(err: grpc.RpcError) -> error_details_pb2.BadRequest:
    st = rpc_status.from_call(err)
    assert st is not None

    bad = error_details_pb2.BadRequest()
    assert len(st.details) >= 1
    assert st.details[0].Unpack(bad)
    return bad


def test_compile_circuit_happy_path(grpc_addr: str) -> None:
    channel = grpc.insecure_channel(grpc_addr)
    stub = comp_pb_grpc.CompilationServiceStub(channel)

    resp = stub.CompileCircuit(
        comp_pb.CompileCircuitRequest(
            language="eigen-lang",
            source=(
                b"from eigen_lang import hybrid_program\n\n"
                b"@hybrid_program()\n"
                b"def main():\n"
                b"    ry(0, theta=1.0)\n"
            ),
        )
    )

    assert resp.circuit.format == _enum_value(types_pb, "CIRCUIT_FORMAT_AQO_JSON", "AQO_JSON")
    assert resp.metadata["aqo_version"] == "1.0.0"
    assert len(resp.circuit.data) > 0
    assert resp.metadata["distributed.execution_metadata_version"] == "1.0.0"
    assert resp.metadata["distributed.enabled"] == "false"


def test_compile_circuit_emits_distributed_metadata_hints(grpc_addr: str) -> None:
    channel = grpc.insecure_channel(grpc_addr)
    stub = comp_pb_grpc.CompilationServiceStub(channel)

    resp = stub.CompileCircuit(
        comp_pb.CompileCircuitRequest(
            language="eigen-lang",
            source=(
                b"from eigen_lang import hybrid_program\n\n"
                b"@hybrid_program()\n"
                b"def main():\n"
                b"    ry(0, theta=1.0)\n"
            ),
            options={
                "distributed.enabled": "true",
                "distributed.target": "cluster",
                "distributed.partition_count": "8",
                "distributed.queue_provider": "redis",
                "distributed.topology_hint": "data_parallel",
            },
        )
    )

    assert resp.metadata["distributed.execution_metadata_version"] == "1.0.0"
    assert resp.metadata["distributed.topology_hints_version"] == "1.0.0"
    assert resp.metadata["distributed.enabled"] == "true"
    assert resp.metadata["distributed.target"] == "cluster"
    assert resp.metadata["distributed.partition_count"] == "8"
    assert resp.metadata["distributed.queue_provider"] == "redis"
    assert resp.metadata["distributed.topology_hint"] == "data_parallel"


def test_compile_circuit_requires_input(grpc_addr: str) -> None:
    channel = grpc.insecure_channel(grpc_addr)
    stub = comp_pb_grpc.CompilationServiceStub(channel)

    with pytest.raises(grpc.RpcError) as e:
        stub.CompileCircuit(comp_pb.CompileCircuitRequest(language="eigen-lang"))

    assert e.value.code() == grpc.StatusCode.INVALID_ARGUMENT
    bad = _extract_bad_request(e.value)
    assert {v.field for v in bad.field_violations} == {"input"}


def test_compile_circuit_rejects_unsupported_language(grpc_addr: str) -> None:
    channel = grpc.insecure_channel(grpc_addr)
    stub = comp_pb_grpc.CompilationServiceStub(channel)

    with pytest.raises(grpc.RpcError) as e:
        stub.CompileCircuit(comp_pb.CompileCircuitRequest(language="qasm3", source=b"OPENQASM 3;"))

    assert e.value.code() == grpc.StatusCode.INVALID_ARGUMENT
    bad = _extract_bad_request(e.value)
    assert {v.field for v in bad.field_violations} == {"language"}


def test_compile_job_requires_job_id(grpc_addr: str) -> None:
    channel = grpc.insecure_channel(grpc_addr)
    stub = comp_pb_grpc.CompilationServiceStub(channel)

    with pytest.raises(grpc.RpcError) as e:
        stub.CompileJob(comp_pb.CompileJobRequest(language="eigen-lang", source_ref="qfs://src.eigen"))

    assert e.value.code() == grpc.StatusCode.INVALID_ARGUMENT
    bad = _extract_bad_request(e.value)
    assert {v.field for v in bad.field_violations} == {"job_id"}


def test_compile_circuit_rejects_forbidden_import(grpc_addr: str) -> None:
    channel = grpc.insecure_channel(grpc_addr)
    stub = comp_pb_grpc.CompilationServiceStub(channel)

    with pytest.raises(grpc.RpcError) as e:
        stub.CompileCircuit(
            comp_pb.CompileCircuitRequest(
                language="eigen-lang",
                source=b"import os\nfrom eigen_lang import *\n",
            )
        )

    assert e.value.code() == grpc.StatusCode.INVALID_ARGUMENT
    bad = _extract_bad_request(e.value)
    assert {v.field for v in bad.field_violations} == {"source"}


def test_compile_circuit_enforces_source_size_limit(
    grpc_addr: str,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("EIGEN_COMPILER_MAX_SOURCE_BYTES", "12")
    channel = grpc.insecure_channel(grpc_addr)
    stub = comp_pb_grpc.CompilationServiceStub(channel)

    with pytest.raises(grpc.RpcError) as e:
        stub.CompileCircuit(
            comp_pb.CompileCircuitRequest(language="eigen-lang", source=b"from eigen_lang import *")
        )

    assert e.value.code() == grpc.StatusCode.INVALID_ARGUMENT
    bad = _extract_bad_request(e.value)
    assert {v.field for v in bad.field_violations} == {"source"}


def test_compile_circuit_rejects_invalid_syntax(grpc_addr: str) -> None:
    channel = grpc.insecure_channel(grpc_addr)
    stub = comp_pb_grpc.CompilationServiceStub(channel)

    with pytest.raises(grpc.RpcError) as e:
        stub.CompileCircuit(
            comp_pb.CompileCircuitRequest(
                language="eigen-lang",
                source=b"from eigen_lang import hybrid_program\n\ndef broken(:\n    pass\n",
            )
        )

    assert e.value.code() == grpc.StatusCode.INVALID_ARGUMENT
    bad = _extract_bad_request(e.value)
    assert {v.field for v in bad.field_violations} == {"source"}

def test_compile_circuit_requires_single_hybrid_program_entrypoint(grpc_addr: str) -> None:
    channel = grpc.insecure_channel(grpc_addr)
    stub = comp_pb_grpc.CompilationServiceStub(channel)

    with pytest.raises(grpc.RpcError) as e:
        stub.CompileCircuit(
            comp_pb.CompileCircuitRequest(
                language="eigen-lang",
                source=(
                    b"from eigen_lang import hybrid_program\n\n"
                    b"def not_entrypoint():\n"
                    b"    ry(0, theta=1.0)\n"
                ),
            )
        )

    assert e.value.code() == grpc.StatusCode.INVALID_ARGUMENT
    bad = _extract_bad_request(e.value)
    assert {v.field for v in bad.field_violations} == {"source"}
    assert any("exactly one @hybrid_program entrypoint is required" in v.description for v in bad.field_violations)


def test_compile_circuit_returns_structured_violations(grpc_addr: str) -> None:
    channel = grpc.insecure_channel(grpc_addr)
    stub = comp_pb_grpc.CompilationServiceStub(channel)

    with pytest.raises(grpc.RpcError) as e:
        stub.CompileCircuit(
            comp_pb.CompileCircuitRequest(
                language="eigen-lang",
                source=(
                    b"import os\n\n"
                    b"def bad_program():\n"
                    b"    eval('1+1')\n"
                    b"    os.system('echo hi')\n"
                ),
            )
        )

    assert e.value.code() == grpc.StatusCode.INVALID_ARGUMENT
    bad = _extract_bad_request(e.value)
    assert len(bad.field_violations) >= 3
    descriptions = [v.description for v in bad.field_violations]
    assert any("import 'os'" in desc for desc in descriptions)
    assert any("call 'eval'" in desc for desc in descriptions)
    assert any("dynamic I/O call 'os.system'" in desc for desc in descriptions)


def test_compile_circuit_rejects_unsupported_distributed_config(grpc_addr: str) -> None:
    channel = grpc.insecure_channel(grpc_addr)
    stub = comp_pb_grpc.CompilationServiceStub(channel)

    with pytest.raises(grpc.RpcError) as e:
        stub.CompileCircuit(
            comp_pb.CompileCircuitRequest(
                language="eigen-lang",
                source=(
                    b"from eigen_lang import hybrid_program\n\n"
                    b"@hybrid_program()\n"
                    b"def main():\n"
                    b"    ry(0, theta=1.0)\n"
                ),
                options={
                    "distributed.enabled": "false",
                    "distributed.target": "cluster",
                    "distributed.partition_count": "0",
                    "distributed.queue_provider": "unknown",
                    "distributed.topology_hint": "mesh",
                },
            )
        )

    assert e.value.code() == grpc.StatusCode.INVALID_ARGUMENT
    bad = _extract_bad_request(e.value)
    assert [v.field for v in bad.field_violations] == [
        "options.distributed.partition_count",
        "options.distributed.queue_provider",
        "options.distributed.topology_hint",
        "options.distributed.target",
        "options.distributed.partition_count",
        "options.distributed.queue_provider",
        "options.distributed.topology_hint",
    ]
